-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CountParts] AS
BEGIN
	
	SELECT Count(QTY)  as TotalStock
	from [ERP_MES].[dbo].[inventory_avenger_840]

END
GO

