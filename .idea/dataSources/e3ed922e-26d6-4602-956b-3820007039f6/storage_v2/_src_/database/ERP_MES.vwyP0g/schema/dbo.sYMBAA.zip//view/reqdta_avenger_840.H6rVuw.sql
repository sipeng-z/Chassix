CREATE VIEW dbo.Requirements
AS
SELECT        HOUSE, ITNBR, CONVERT(DateTime, CONVERT(VarChar(8), DUEDT + 19000000)) AS DUEDT, QTY
FROM            OPENQUERY(avenger, 'select * from chxmes840.reqdta') AS derivedtbl_1
GO

