CREATE VIEW dbo.inventory_avenger_840
AS
SELECT        SITE, HOUSE, ITEM, ITMDESC, ITTYP, ITAC, LOCN, QTY, FORDESC, LEGACYNO, PGM, PGMDESC1, BATCHLOT
FROM            OPENQUERY(avenger, 'select * from chxmes840.inventory') AS derivedtbl_1
GO

